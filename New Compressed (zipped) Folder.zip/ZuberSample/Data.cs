﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ZuberSample.Models;

namespace ZuberSample
{
    static class Data
    {
        public static List<Admins> admins = new List<Admins>();
        public static List<Customers> customers = new List<Customers>();
        public static List<Driver> drivers = new List<Driver>();
    }
}
